package com.abhay.dtlogger

import android.content.Context
import java.io.File

object Store {
    const val HEADER = "round,time,dragon_card,tiger_card,winner,dragon_total,tie_total,tiger_total,winning_amount,star_side,star_won,history"

    private fun file(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "rounds.csv")

    @Synchronized
    fun nextRound(c: Context): Int {
        val p = c.getSharedPreferences("dt", Context.MODE_PRIVATE)
        val n = p.getInt("n", 0) + 1
        p.edit().putInt("n", n).apply()
        return n
    }

    @Synchronized
    fun append(c: Context, line: String) {
        val f = file(c)
        if (!f.exists()) f.writeText(HEADER + "\n")
        f.appendText(line + "\n")
    }

    /** Newest round pehle. */
    @Synchronized
    fun rows(c: Context): List<List<String>> {
        val f = file(c)
        if (!f.exists()) return emptyList()
        return f.readLines().drop(1)
            .filter { it.isNotBlank() }
            .map { it.split(",") }
            .filter { it.size >= 12 }
            .reversed()
    }

    @Synchronized
    fun csv(c: Context): String {
        val f = file(c)
        return if (f.exists()) f.readText() else HEADER + "\n"
    }

    @Synchronized
    fun clear(c: Context) {
        file(c).delete()
        c.getSharedPreferences("dt", Context.MODE_PRIVATE).edit().putInt("n", 0).apply()
    }
}
