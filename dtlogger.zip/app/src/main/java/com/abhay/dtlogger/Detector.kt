package com.abhay.dtlogger

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

data class Cards(val d: Int, val t: Int, val dc: String, val tc: String)
data class Extra(
    val dAmt: Double?, val tieAmt: Double?, val tAmt: Double?,
    val star: String, val history: String
)

/**
 * Saare regions 1600x720 screenshot se naape gaye fractions hain:
 * [left, top, right, bottom]. Kuch galat padhe to sirf yahi numbers badalne hain.
 */
object Detector {
    private val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val RANKS = listOf("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")

    private val D_RANK = floatArrayOf(0.4325f, 0.054f, 0.4625f, 0.113f)
    private val T_RANK = floatArrayOf(0.5388f, 0.054f, 0.5688f, 0.113f)
    private val D_SUIT = floatArrayOf(0.445f, 0.132f, 0.4875f, 0.229f)
    private val T_SUIT = floatArrayOf(0.550f, 0.132f, 0.594f, 0.229f)

    private val D_AMT = floatArrayOf(0.286f, 0.383f, 0.3825f, 0.447f)
    private val TIE_AMT = floatArrayOf(0.472f, 0.383f, 0.566f, 0.447f)
    private val T_AMT = floatArrayOf(0.653f, 0.383f, 0.747f, 0.447f)

    private val D_STAR = floatArrayOf(0.2444f, 0.380f, 0.2744f, 0.447f)
    private val TIE_STAR = floatArrayOf(0.4306f, 0.380f, 0.4606f, 0.447f)
    private val T_STAR = floatArrayOf(0.610f, 0.380f, 0.640f, 0.447f)

    private const val H_X0 = 0.275f
    private const val H_STEP = 0.02705f
    private const val H_Y = 0.3236f
    private const val H_N = 16

    fun label(r: Int): String = RANKS[r - 1]

    private fun crop(b: Bitmap, r: FloatArray): Bitmap {
        val x = (r[0] * b.width).toInt().coerceIn(0, b.width - 1)
        val y = (r[1] * b.height).toInt().coerceIn(0, b.height - 1)
        val w = ((r[2] - r[0]) * b.width).toInt().coerceIn(1, b.width - x)
        val h = ((r[3] - r[1]) * b.height).toInt().coerceIn(1, b.height - y)
        return Bitmap.createBitmap(b, x, y, w, h)
    }

    private fun pixels(c: Bitmap): IntArray {
        val px = IntArray(c.width * c.height)
        c.getPixels(px, 0, c.width, 0, 0, c.width, c.height)
        return px
    }

    private fun ocr(b: Bitmap, scale: Int): String {
        val big = Bitmap.createScaledBitmap(b, b.width * scale, b.height * scale, true)
        val pad = Bitmap.createBitmap(big.width + 40, big.height + 40, Bitmap.Config.ARGB_8888)
        val cv = Canvas(pad)
        cv.drawColor(big.getPixel(0, 0))
        cv.drawBitmap(big, 20f, 20f, null)
        return try {
            Tasks.await(rec.process(InputImage.fromBitmap(pad, 0))).text
        } catch (e: Exception) {
            ""
        }
    }

    private fun rank(c: Bitmap): Int? {
        val t = ocr(c, 4).uppercase().filter { it.isLetterOrDigit() }
        val m = Regex("10|[A2-9JQK]").find(t) ?: return null
        return RANKS.indexOf(m.value) + 1
    }

    /** R = red (diamond/heart), B = black (club/spade). */
    private fun suit(b: Bitmap, r: FloatArray): String {
        var red = 0
        var dark = 0
        for (p in pixels(crop(b, r))) {
            val rr = Color.red(p)
            val gg = Color.green(p)
            val bb = Color.blue(p)
            if (rr > 150 && gg < 100 && bb < 100) red++
            else if (rr < 90 && gg < 90 && bb < 90) dark++
        }
        return if (red < 15 && dark < 15) "?" else if (red > dark) "R" else "B"
    }

    private fun amount(b: Bitmap, r: FloatArray): Double? {
        val t = ocr(crop(b, r), 3).replace(",", "").replace(" ", "")
        return Regex("\\d+(\\.\\d+)?").findAll(t).map { it.value }
            .maxByOrNull { it.length }?.toDoubleOrNull()
    }

    private fun gold(b: Bitmap, r: FloatArray): Float {
        val px = pixels(crop(b, r))
        var n = 0
        for (p in px) {
            val rr = Color.red(p)
            val gg = Color.green(p)
            val bb = Color.blue(p)
            if (rr > 200 && gg in 140..230 && bb < 110) n++
        }
        return n.toFloat() / px.size
    }

    private fun history(b: Bitmap): String {
        val out = ArrayList<String>()
        val cy = (H_Y * b.height).toInt().coerceIn(0, b.height - 1)
        val off = (0.0075f * b.width).toInt()
        for (i in 0 until H_N) {
            val cx = ((H_X0 + i * H_STEP) * b.width).toInt()
            val p1 = b.getPixel((cx - off).coerceIn(0, b.width - 1), cy)
            val p2 = b.getPixel((cx + off).coerceIn(0, b.width - 1), cy)
            val r = (Color.red(p1) + Color.red(p2)) / 2
            val g = (Color.green(p1) + Color.green(p2)) / 2
            val bl = (Color.blue(p1) + Color.blue(p2)) / 2
            val s = when {
                bl > r + 40 && bl > g + 20 -> "D"
                g > r + 25 && g > bl + 25 -> "Tie"
                r > bl + 60 -> "T"
                else -> null
            } ?: break
            out.add(s)
        }
        return out.joinToString(" ")
    }

    fun cards(b: Bitmap): Cards? {
        val d = rank(crop(b, D_RANK)) ?: return null
        val t = rank(crop(b, T_RANK)) ?: return null
        return Cards(d, t, suit(b, D_SUIT), suit(b, T_SUIT))
    }

    fun extra(b: Bitmap): Extra {
        val stars = listOf("D" to gold(b, D_STAR), "Tie" to gold(b, TIE_STAR), "T" to gold(b, T_STAR))
        val best = stars.maxByOrNull { it.second }!!
        val star = if (best.second > 0.06f) best.first else "-"
        return Extra(amount(b, D_AMT), amount(b, TIE_AMT), amount(b, T_AMT), star, history(b))
    }
}
