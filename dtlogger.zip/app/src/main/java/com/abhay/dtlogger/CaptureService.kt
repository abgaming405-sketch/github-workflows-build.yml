package com.abhay.dtlogger

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var w = 0
    private var h = 0
    private var dpi = 0
    private var last: Bitmap? = null
    private var overlay: TextView? = null
    private var running = false

    private val ui = Handler(Looper.getMainLooper())
    private val ht = HandlerThread("dt-reader")
    private lateinit var bg: Handler

    private var lastSig = ""
    private var lastSaved = ""
    private var stable = 0
    private var armed = true

    private val dl = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) { rebuild() }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (running) return START_NOT_STICKY
        startFg()
        val code = i?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, ui)
        val s = size()
        w = s.first
        h = s.second
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = projection?.createVirtualDisplay(
            "dt", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null
        )
        getSystemService(DisplayManager::class.java).registerDisplayListener(dl, ui)
        showOverlay()
        ht.start()
        bg = Handler(ht.looper)
        running = true
        bg.postDelayed({ tick() }, 1000)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("dt", "DT Logger", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "dt")
            .setContentTitle("DT Logger chalu hai")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun size(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        dpi = dm.densityDpi
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    @Synchronized
    private fun rebuild() {
        if (vd == null) return
        val s = size()
        if (s.first == w && s.second == h) return
        w = s.first
        h = s.second
        val old = reader
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd?.resize(w, h, dpi)
        vd?.surface = reader?.surface
        old?.close()
        last = null
    }

    @Synchronized
    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val p = img.planes[0]
                val pad = p.rowStride - p.pixelStride * img.width
                val wide = Bitmap.createBitmap(
                    img.width + pad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888
                )
                wide.copyPixelsFromBuffer(p.buffer)
                last = Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
            } finally {
                img.close()
            }
        }
        return last
    }

    private fun tick() {
        if (!running) return
        try {
            val b = grab()
            if (b != null && b.width > b.height) {
                val c = Detector.cards(b)
                if (c == null) {
                    armed = true
                    stable = 0
                    lastSig = ""
                } else {
                    val sig = "${c.d}${c.dc}-${c.t}${c.tc}"
                    if (sig == lastSig) stable++ else { lastSig = sig; stable = 1 }
                    if (sig != lastSaved) armed = true
                    if (armed && stable >= 3) {
                        save(b, c)
                        lastSaved = sig
                        armed = false
                    }
                }
            }
        } catch (e: Exception) {
        }
        if (running) bg.postDelayed({ tick() }, 700)
    }

    private fun save(b: Bitmap, c: Cards) {
        val e = Detector.extra(b)
        val win = when {
            c.d > c.t -> "D"
            c.t > c.d -> "T"
            else -> "Tie"
        }
        val amt = when (win) {
            "D" -> e.dAmt
            "T" -> e.tAmt
            else -> e.tieAmt
        }
        val starWon = e.star == win
        val shown = if (starWon) "$win*" else win
        fun n(x: Double?) = if (x == null) "?" else String.format(Locale.US, "%.2f", x)
        val rnd = Store.nextRound(this)
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val line = listOf(
            rnd.toString(), time,
            Detector.label(c.d) + c.dc, Detector.label(c.t) + c.tc,
            shown, n(e.dAmt), n(e.tieAmt), n(e.tAmt), n(amt),
            e.star, if (e.star == "-") "-" else if (starWon) "yes" else "no",
            e.history
        ).joinToString(",")
        Store.append(this, line)
        ui.post { overlay?.text = "DT Logger | rounds: $rnd | last: $shown | tap=stop" }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val tv = TextView(this)
        tv.text = "DT Logger | tap=stop"
        tv.textSize = 11f
        tv.setTextColor(Color.WHITE)
        tv.setBackgroundColor(Color.argb(150, 0, 0, 0))
        tv.setPadding(14, 6, 14, 6)
        tv.setOnClickListener { stopSelf() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 160
        getSystemService(WindowManager::class.java).addView(tv, lp)
        overlay = tv
    }

    override fun onDestroy() {
        running = false
        try {
            getSystemService(DisplayManager::class.java).unregisterDisplayListener(dl)
        } catch (e: Exception) {
        }
        vd?.release()
        reader?.close()
        projection?.stop()
        overlay?.let {
            try {
                getSystemService(WindowManager::class.java).removeView(it)
            } catch (e: Exception) {
            }
        }
        ht.quitSafely()
        super.onDestroy()
    }
}
