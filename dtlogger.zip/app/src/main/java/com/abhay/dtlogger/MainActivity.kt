package com.abhay.dtlogger

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var summary: TextView
    private lateinit var list: ListView

    private val capture = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", r.resultCode)
                .putExtra("data", data)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "Chalu ho gaya. Ab game kholo.", Toast.LENGTH_LONG).show()
        }
    }

    private val export = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(Store.csv(this).toByteArray()) }
            Toast.makeText(this, "CSV save ho gayi", Toast.LENGTH_SHORT).show()
        }
    }

    private val notif = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(32, 32, 32, 32)

        fun btn(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { f() }
            root.addView(b)
        }
        btn("Start logging") { start() }
        btn("Stop") { stopService(Intent(this, CaptureService::class.java)) }
        btn("Export CSV") { export.launch("dragon_tiger_rounds.csv") }
        btn("Clear all") { confirmClear() }

        summary = TextView(this)
        summary.textSize = 15f
        summary.setPadding(0, 24, 0, 24)
        root.addView(summary)

        list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(this, "Overlay permission do, phir Start dabao", Toast.LENGTH_LONG).show()
            return
        }
        capture.launch(
            getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent()
        )
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setMessage("Saare records delete karun?")
            .setPositiveButton("Haan") { _, _ -> Store.clear(this); refresh() }
            .setNegativeButton("Nahi", null)
            .show()
    }

    private fun refresh() {
        val rows = Store.rows(this)
        fun cnt(k: String) = rows.count { it[4].trimEnd('*') == k }
        val starRounds = rows.count { it[9] != "-" }
        val starWins = rows.count { it[10] == "yes" }
        summary.text = "Rounds: ${rows.size}  |  Dragon ${cnt("D")}  Tiger ${cnt("T")}  Tie ${cnt("Tie")}\n" +
            "Star side jeeta: $starWins / $starRounds"
        val items = rows.map { r ->
            "#${r[0]}   ${r[4]}   (${r[2]} vs ${r[3]})\n" +
                "D ${r[5]}  |  Tie ${r[6]}  |  T ${r[7]}\n" +
                "Win amt: ${r[8]}   Star: ${r[9]}\n${r[1]}"
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
    }
}
